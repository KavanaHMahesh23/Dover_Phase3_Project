﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IdentitySecuredApp.Migrations
{
    public partial class LaptopViewModelModified1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
